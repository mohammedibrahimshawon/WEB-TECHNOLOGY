<footer id="footer" class="footer-wrapper">
	 <div class="container">
			 <div class="row">
					 <div class="col-lg-8 col-md-8 col-sm-8">
								<h1 class="quick-links-title">BOOKSHOP</h1>
								<p>© Copyright 2021 | BOOKSHOP Limited</p>
								<p class="address">road 15,C block, Bosundhoara Residential  Area, Dhaka</p>
					 </div>
					 <div class="col-lg-4 col-md-4 col-sm-4">
							 <h1 class="quick-links-title">QUICK LINKS</h1>
							 <ul class="quick-links">
									 <li><a href="homepage.php">Home</a></li>
									<!--  <li><a href="stocks.php">Current Stock</a></li>
									 <li><a href="sell.php">Sell Your Car</a></li>
									 <li><a href="team.php">Team</a></li> -->
									 <!-- <li><a href="aboutus.php">About Us</a></li>
									 <li><a href="contactus.php">Contact Us</a></li> -->


							 </ul>
					 </div>

			 </div>
	 </div>



</footer>
</html>

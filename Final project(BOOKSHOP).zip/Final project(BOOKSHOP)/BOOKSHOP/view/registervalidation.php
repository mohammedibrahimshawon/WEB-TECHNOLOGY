<?php
include('../control/db.php');





?>